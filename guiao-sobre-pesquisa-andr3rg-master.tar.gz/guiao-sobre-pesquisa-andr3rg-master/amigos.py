from constraintsearch import *

amigos = ["Andre", "Bernardo", "Claudio"]

cs = ConstraintSearch(None, None)

print(cs.search())
